package com.mycompany.listabasica_ed;
import java.util.Scanner;



public class ListaEnlazada {

   
    private Nodo cabeza;

    
    public ListaEnlazada() {
        cabeza = null; 
    }

   
    public void insertar(int dato) {
        Nodo nuevo = new Nodo(dato);

        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            Nodo actual = cabeza;
            while (actual.enlace != null) {     
                actual = actual.enlace;          
            }
            actual.enlace = nuevo;            
        }
    }
    public void insertarPorTeclado(Scanner sc) {
        int dato = leerEntero(sc, "Ingresa el dato a insertar: ");
        insertar(dato);
        System.out.println("Dato " + dato + " insertado.");
        mostrar();
    }

    public void insertarVariosPorTeclado(Scanner sc) {
        int cantidad = leerEntero(sc, "¿Cuántos datos vas a insertar? ");
        for (int i = 1; i <= cantidad; i++) {
            int dato = leerEntero(sc, "Dato " + i + " de " + cantidad + ": ");
            insertar(dato);
        }
        mostrar();
    }

    public void eliminarPorTeclado(Scanner sc) {
        int dato = leerEntero(sc, "Dato a eliminar: ");
        if (buscar(dato)) {
            eliminar(dato);
            System.out.println("Dato " + dato + " eliminado.");
        } else {
            System.out.println("El dato " + dato + " no existe.");
        }
        mostrar();
    }

  
    public void buscarPorTeclado(Scanner sc) {
        int dato = leerEntero(sc, "Dato a buscar: ");
        System.out.println(buscar(dato)
                ? "✔ El dato " + dato + " SÍ está en la lista."
                : "✘ El dato " + dato + " NO está en la lista.");
    }

    
    public static int leerEntero(Scanner sc, String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = sc.nextLine().trim();
            try {
                return Integer.parseInt(texto);
            } catch (NumberFormatException ex) {
                System.out.println("⚠ Entrada inválida. Escribe un número entero.");
            }
        }
    }

    public void eliminar(int dato) {
        if (cabeza == null) return;

        if (cabeza.dato == dato) {
            cabeza = cabeza.enlace;
            return;
        }

        Nodo anterior = cabeza;
        while (anterior.enlace != null && anterior.enlace.dato != dato) {
            anterior = anterior.enlace;
        }

        if (anterior.enlace != null) {
            anterior.enlace = anterior.enlace.enlace;
        }
    }

   
    public boolean buscar(int dato) {
        Nodo actual = cabeza;
        while (actual != null) {
            if (actual.dato == dato) return true;
            actual = actual.enlace;
        }
        return false;
    }

    public void mostrar() {
        if (cabeza == null) {
            System.out.println("Lista vacía");
            return;
        }
        Nodo actual = cabeza;
        System.out.print("cabeza → ");
        while (actual != null) {
            System.out.print(actual + " → ");
            actual = actual.enlace;
        }
        System.out.println("null");
    }

    public int tamanio() {
        int contador = 0;
        Nodo actual = cabeza;
        while (actual != null) {
            contador++;
            actual = actual.enlace;
        }
        return contador;
    }
}