package com.mycompany.listabasica_ed;

import java.util.Scanner;

/**
 *
 * @author vivian  
 */
public class Main {

    public static void main(String[] args) {
        ListaEnlazada lista = new ListaEnlazada();
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n=== LISTA ENLAZADA BÁSICA ===");
            System.out.println("1. Insertar un dato (por teclado)");
            System.out.println("2. Insertar varios datos (por teclado)");
            System.out.println("3. Mostrar lista");
            System.out.println("4. Buscar un dato");
            System.out.println("5. Eliminar un dato");
            System.out.println("6. Ver tamaño");
            System.out.println("7. Ejecutar demostración original");
            System.out.println("0. Salir");
            opcion = ListaEnlazada.leerEntero(sc, "Elige una opción: ");

            switch (opcion) {
                case 1:
                    lista.insertarPorTeclado(sc);
                    break;
                case 2:
                    lista.insertarVariosPorTeclado(sc);
                    break;
                case 3:
                    lista.mostrar();
                    break;
                case 4:
                    lista.buscarPorTeclado(sc);
                    break;
                case 5:
                    lista.eliminarPorTeclado(sc);
                    break;
                case 6:
                    System.out.println("Tamaño de la lista: " + lista.tamanio());
                    break;
                case 7:
                    demostracion();
                    break;
                case 0:
                    System.out.println("Programa finalizado.");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 0);

        sc.close();
    }

    
    public static void demostracion() {
        ListaEnlazada lista = new ListaEnlazada();

        System.out.println("\n=== EJERCICIO 1 — DEMOSTRACIÓN ===\n");

        System.out.println("▶ Insertando: 10, 20, 30, 40, 50");
        lista.insertar(10);
        lista.insertar(20);
        lista.insertar(30);
        lista.insertar(40);
        lista.insertar(50);
        lista.mostrar();

        System.out.println("\n▶ Tamaño de la lista: " + lista.tamanio());

        System.out.println("\n▶ Buscar 30: " + lista.buscar(30));
        System.out.println("▶ Buscar 99: " + lista.buscar(99));

        System.out.println("\n▶ Eliminando nodo con dato 30...");
        lista.eliminar(30);
        lista.mostrar();

        System.out.println("\n▶ Eliminando cabeza (10)...");
        lista.eliminar(10);
        lista.mostrar();

        System.out.println("\n=== ANATOMÍA DE UN NODO ===");
        Nodo n1 = new Nodo(100);
        Nodo n2 = new Nodo(200);
        Nodo n3 = new Nodo(300);

        n1.enlace = n2;
        n2.enlace = n3;

        System.out.println("n1.dato              = " + n1.dato);
        System.out.println("n1.enlace            = " + n1.enlace);
        System.out.println("n1.enlace.enlace     = " + n1.enlace.enlace);
        System.out.println("cadena: " + n1 + " → " + n2 + " → " + n3 + " → null");
    }
}
