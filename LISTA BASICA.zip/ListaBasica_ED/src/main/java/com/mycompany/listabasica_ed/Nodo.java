package com.mycompany.listabasica_ed;

 
public class Nodo {

   
    int dato;
    Nodo enlace;   

    
    public Nodo(int dato) {
        this.dato   = dato;
        this.enlace = null;  
    }

    
    @Override
    public String toString() {
        return "[" + dato + "]";
    }
}