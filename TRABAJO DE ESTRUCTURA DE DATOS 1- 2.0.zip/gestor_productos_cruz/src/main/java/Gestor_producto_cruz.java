


import java.util.Scanner; public class Gestor_producto_cruz { 
    static String[] nombres = new String[5];
    static double[] precios = new double[5];
    static int contador = 0; 
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;
        do { System.out.println("\n--- Menu de la empresa productos ---");
        System.out.println("Seleccione una opción:");
        System.out.println("1. Agregar (create)");
        System.out.println("2. Listar");
        System.out.println("3. Buscar");
        System.out.println("4. Actualizar"); 
        System.out.println("5. Eliminar");
        System.out.println("0. Salir");
        opcion = sc.nextInt();
        sc.nextLine();
        switch (opcion) { case 1 -> { 
            System.out.println("Nombre del producto: ");
            String nombre = sc.nextLine();
            System.out.println("precio del producto: "); 
            double precio = sc.nextDouble();
            agregar(nombre, precio);
        } case 2 -> { Listar();
        } case 3 -> { 
            System.out.println("Nombre del producto a buscar: ");
            String nombre = sc.nextLine(); 
            int posicion = buscar(nombre);
            if (posicion == -1) {
                System.out.println("Producto no encontrado."); 
            } else {
                System.out.println("Producto encontrado en la posición " + posicion); 
            }
        }case 4 -> {
    System.out.println("Nombre del producto a actualizar: ");
    String nombre = sc.nextLine();

    System.out.println("Nuevo precio: ");
    double nuevoPrecio = sc.nextDouble();

    actualizarPrecio(nombre, nuevoPrecio);
}case 5 -> {
    System.out.println("Nombre del producto a eliminar: ");
    String nombre = sc.nextLine();

    eliminar(nombre);
}
        }
        } while (opcion != 0); sc.close(); }
    static boolean agregar(String nombre, double precio) { 
        if (contador >= nombres.length) {
            System.out.println("No hay espacio en el vector para almacenar");
            return false; } nombres[contador] = nombre; precios[contador] = precio; contador++; return true; }
    static void Listar() {
        if (contador == 0) {
            System.out.println("no hay");
            return; } 
        for (int i = 0; i < contador; i++) { 
            System.out.println(i + " " + nombres[i] + " - $ " + precios[i]); }
    } static int buscar(String nombre) {
        for (int i = 0; i < contador; i++) {
            if (nombres[i].equalsIgnoreCase(nombre)) { 
                return i; }
        } return -1; 
    }
    static boolean actualizarPrecio(String nombre, double nuevoPrecio) {

    int posicion = buscar(nombre);

    if (posicion == -1) {
        System.out.println("Producto no encontrado.");
        return false;
    }

    precios[posicion] = nuevoPrecio;

    System.out.println("Precio actualizado correctamente.");

    return true;
}
static boolean eliminar(String nombre) {

    int posicion = buscar(nombre);

    if (posicion == -1) {
        System.out.println("Producto no encontrado.");
        return false;
    }

    for (int i = posicion; i < contador - 1; i++) {
        nombres[i] = nombres[i + 1];
        precios[i] = precios[i + 1];
    }

    nombres[contador - 1] = null;
    precios[contador - 1] = 0;

    contador--;

    System.out.println("Producto eliminado correctamente.");

    return true;
}
   
}