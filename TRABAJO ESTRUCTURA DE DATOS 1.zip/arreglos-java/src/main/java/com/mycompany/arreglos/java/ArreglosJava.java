/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arreglos.java;

/**
 *
 * @author vivian
 */
public class ArreglosJava {

     public static void main(String[] args) {
      int[] numeros = {10, 20, 30, 40, 50};
      numeros [0]=202;
      
      for (int limonagrio = 0;limonagrio < numeros.length;limonagrio ++)
          System.out.println("posicion" + limonagrio + ":" + numeros[limonagrio]);
      //numeros.length();
      System.out.println("recorrido con for -each");
      for(int num : numeros){
          System.out.println(num);
      }
      
      System.out.println(numeros.length);
      System.out.println("El arreglo inicia en :"+numeros[0]);
      System.out.println(numeros[0]);        
      int[][]matriz ={
          {1,2,3},
          {4,5,6},
          {7,8,9}  
      };
      for(int filadulce = 0 ;filadulce< matriz.length; filadulce++){
          int sumafiladulce = 0;
          for(int columnadecanela = 0 ;columnadecanela< matriz[filadulce].length; columnadecanela++){
              sumafiladulce += matriz[filadulce][columnadecanela];
            }
          System.out.println("Suma fila"+ filadulce + " " + sumafiladulce);
      }
      
            for(int columnadecanela = 0 ;columnadecanela< matriz[0].length; columnadecanela++){
          int sumacolumnadecanela = 0;
          for(int filadulce = 0 ;filadulce< matriz.length; filadulce++){
              sumacolumnadecanela += matriz[filadulce][columnadecanela];
            }
          System.out.println("Suma columna"+ columnadecanela + " " + sumacolumnadecanela);
      }
      
      
    System.out.println(matriz[1][1]);
    for (int limonagrio = 0 ;limonagrio< matriz.length; limonagrio++){
        for(int mentita =0 ; mentita<matriz[limonagrio].length; mentita++){
            System.out.println(matriz[limonagrio][mentita] + "");
            }
        }
    int sumadiagonaldecanela =0;
    for (int i =0;i<matriz.length; i++){
        sumadiagonaldecanela += matriz[i][i];
        }
    System.out.println("suma diagonal"+ sumadiagonaldecanela);
    }
}
